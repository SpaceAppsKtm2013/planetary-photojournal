//
//  PhotojournalWebAPI.h
//  StraatJutter
//
//  Created by Samesh3mikha on 20/4/13.
//  Copyright (c) 2012 __BajraTechnologies__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SharedStore.h"

#define SERVER_STRING         @"http://droplet.bajratechnologies.com/photojournal"
//#define SERVER_STRING           @"http://192.168.1.27:8888/photojournal"
#define URL_GET_PHOTOS     @"/photos.php"


@protocol PhotojournalWebAPIDelegate <NSObject>
@optional
    -(void)imageRetreivingFailedWithError:(NSError *)error;
    -(void)imageRetreivingCompletedWithResponse:(NSData *)responseData;

    -(void)photosRetreivingFailedWithError:(NSError *)error;
    -(void)photosRetreivingCompletedWithResponse:(NSData *)responseData;

@end

@interface PhotojournalWebAPI : NSObject {
    NSURLConnection *connectionGetImageForUrl;
    NSMutableData *responseDataGetImageForUrl;
    
    NSURLConnection *connectionGetPhotoList;
    NSMutableData *responseDataGetPhotoList;
    
    id <PhotojournalWebAPIDelegate> delegate;
}

//---------  PROPERTIES ---------

@property(nonatomic, retain) NSURLConnection *connectionGetImageForUrl;
@property(nonatomic, retain) NSMutableData *responseDataGetImageForUrl;

@property(nonatomic, retain) NSURLConnection *connectionGetPhotoList;
@property(nonatomic, retain) NSMutableData *responseDataGetPhotoList;

@property(nonatomic, assign) id <PhotojournalWebAPIDelegate> delegate;

//---------  URLCONNECTION METHODS ---------
-(void)getImageFromUrl:(NSString *)imageUrl;
-(void)getPhotoListForID:(NSInteger)categoryID WhenOffset:(NSInteger)offset inNumber:(NSInteger)number;

//---------  CUSTOM METHODS ---------
-(void)cancelAllConnections;


@end
