//
//  PhotojournalWebAPI.m
//  StraatJutter
//
//  Created by Samesh3mikha on 11/7/12.
//  Copyright (c) 2012 __BajraTechnologies__. All rights reserved.
//

#import "PhotojournalWebAPI.h"
#import "AppDelegate.h"

@implementation PhotojournalWebAPI

@synthesize connectionGetImageForUrl, responseDataGetImageForUrl;
@synthesize connectionGetPhotoList, responseDataGetPhotoList;
@synthesize delegate;

#pragma mark -
#pragma mark ---------- SELF METHODS ----------
-(id)init {
	self = [super init];
	if (self != nil) {
		// initialize stuff here
        responseDataGetImageForUrl      = [[NSMutableData alloc] init];
        responseDataGetPhotoList         = [[NSMutableData alloc] init];
	}
	
	return self;
}

#pragma mark -
#pragma mark ---------- URLCONNECTION METHODS ----------

-(void)getImageFromUrl:(NSString *)imageUrl {
    if (![SharedStore store].hostActive && [SharedStore store].checkedConnection){
        [delegate imageRetreivingFailedWithError:nil];
        return;
    }

    imageUrl = [imageUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *urlRequest = [[[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:imageUrl]] autorelease];
    connectionGetImageForUrl = [[NSURLConnection alloc] initWithRequest:urlRequest delegate:self];
    if (connectionGetImageForUrl) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    }    
}


-(void)getPhotoListForID:(NSInteger)categoryID WhenOffset:(NSInteger)offset inNumber:(NSInteger)number{
    if (![SharedStore store].hostActive && [SharedStore store].checkedConnection){
        [delegate photosRetreivingFailedWithError:nil];
        return;
    }
    
    NSString *connectionString = [NSString stringWithFormat:@"%@%@?category_id=%d&offset=%d&number=%d",SERVER_STRING, URL_GET_PHOTOS, categoryID, offset, number];
    NSURL* url = [NSURL URLWithString:connectionString];
    NSMutableURLRequest *urlRequest = [[[NSMutableURLRequest alloc] initWithURL:url] autorelease];
    [urlRequest setHTTPMethod:@"GET"];
    connectionGetPhotoList = [[NSURLConnection alloc] initWithRequest:urlRequest delegate:self];
    if (connectionGetPhotoList) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    }
}

#pragma mark -
#pragma mark ---------- NSURLCONNECTION DELEGATE METHODS ----------

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {	

    if (connection == connectionGetImageForUrl) {
        [responseDataGetImageForUrl setLength:0];
    }
    else if (connection == connectionGetPhotoList) {
        [responseDataGetPhotoList setLength:0];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    if (connection == connectionGetImageForUrl) {
        [responseDataGetImageForUrl appendData:data];
    }
    else if (connection == connectionGetPhotoList) {
        [responseDataGetPhotoList appendData:data];
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {		
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;

    if (connection == connectionGetImageForUrl) {
        self.connectionGetImageForUrl = nil;

        [delegate imageRetreivingFailedWithError:error];
    }
    else if (connection == connectionGetPhotoList) {
        self.connectionGetPhotoList = nil;
        
        [delegate photosRetreivingFailedWithError:error];
    }
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;

    if (connection == connectionGetImageForUrl) {
        self.connectionGetImageForUrl = nil;
        
        [delegate imageRetreivingCompletedWithResponse:responseDataGetImageForUrl];
    }
    else if (connection == connectionGetPhotoList) {
        self.connectionGetPhotoList = nil;

        [delegate photosRetreivingCompletedWithResponse:responseDataGetPhotoList];
    }
}

#pragma mark -
#pragma mark ---------- CUSTOM METHODS ----------
-(void)cancelAllConnections
{
    if (connectionGetImageForUrl) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        
        [self.connectionGetImageForUrl cancel];
        self.connectionGetImageForUrl = nil;
    }
}


#pragma mark -
#pragma mark ---------- MEMORY MANAGEMENT ----------

-(void)dealloc {
    [responseDataGetImageForUrl release];
    [responseDataGetPhotoList release];
    
    [super dealloc];
}

@end
