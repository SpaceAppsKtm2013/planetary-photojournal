//
//  DatabaseManager.m
//  Clutterly
//
//  Created by Samesh3mikha on 6/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DatabaseManager.h"
#import "SharedStore.h"

@implementation DatabaseManager

@synthesize managedObjectContext;

#pragma mark -
#pragma mark ---------- CUSTOM METHODS ----------

-(void)parseServerResponseItemsListDictionary:(NSString *)itemsDictionaryResponseString {
    NSDictionary *itemsDictionary = [itemsDictionaryResponseString JSONValue];
    
    [self insertItemsToDBFromDictionary:itemsDictionary forOwner:nil];
}


-(void)insertItemsToDBFromDictionary:(NSDictionary *)itemsDictionary forOwner:(id)owner{

    NSArray *itemsArray = nil;
    if ([[itemsDictionary valueForKey:ParamsKey_photos] isKindOfClass:[NSArray class]]) {
        itemsArray = [itemsDictionary valueForKey:ParamsKey_photos];
    }
    
    if (itemsArray.count == 0) return;
    
    for (int i = 0; i < itemsArray.count; i++) {
        NSMutableDictionary *itemDictionary;
        
        if ([[itemsDictionary valueForKey:ParamsKey_photos] isKindOfClass:[NSArray class]]) {
            itemDictionary = (NSMutableDictionary *)[[itemsArray objectAtIndex:i] valueForKey:ParamsKey_photo];
            [self insertPhotoInDBWithDictionary:itemDictionary];
        }
    }
}


-(void)insertPhotoInDBWithDictionary:(NSMutableDictionary *)photoDictionary {
    NSEntityDescription *entity;
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSPredicate *predicate;
    NSError *error;
    
    // CHECK IF ITEM WITH THIS ID IS ALREADY PRESENT
    entity = [NSEntityDescription entityForName:@"Photo" inManagedObjectContext:self.managedObjectContext];
    predicate = [NSPredicate predicateWithFormat:@"id = %@", [NSNumber numberWithInt: (NSInteger)[[photoDictionary valueForKey:DatabaseField_photo_id] intValue]]];
    [fetchRequest setEntity:entity];
    [fetchRequest setPredicate:predicate];
    error = nil;
    
    NSArray *photos = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    // DONT AUTORELEASE fetchRequest
    [fetchRequest release];

    Photo *photo;
    if (photos.count > 0) {
        photo = [photos objectAtIndex:0];
    }
    else {
        photo = [NSEntityDescription insertNewObjectForEntityForName:@"Photo" inManagedObjectContext:self.managedObjectContext];
    
        if ([[photoDictionary  objectForKey:DatabaseField_photo_id] isKindOfClass:[NSString class]]){
            photo.id = [NSNumber numberWithInt: (NSInteger)[[photoDictionary valueForKey:DatabaseField_photo_id] intValue]];
        }
    }
    
    if ([[photoDictionary  objectForKey:DatabaseField_photo_category_id] isKindOfClass:[NSString class]]){
        photo.category_id = [NSNumber numberWithInt: (NSInteger)[[photoDictionary valueForKey:DatabaseField_photo_category_id] intValue]];
    }

    if ([[photoDictionary  objectForKey:DatabaseField_photo_title] isKindOfClass:[NSString class]]){
        photo.title = [(NSString *)[photoDictionary valueForKey:DatabaseField_photo_title]  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }

    if ([[photoDictionary  objectForKey:ParamsKey_description] isKindOfClass:[NSString class]]){
        photo.details = [(NSString *)[photoDictionary valueForKey:ParamsKey_description]  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }
    
    if ([[photoDictionary  objectForKey:DatabaseField_photo_mission] isKindOfClass:[NSString class]]){
        photo.mission = [(NSString *)[photoDictionary valueForKey:DatabaseField_photo_mission]  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }
    
    if ([[photoDictionary  objectForKey:DatabaseField_photo_target] isKindOfClass:[NSString class]]){
        photo.target = [(NSString *)[photoDictionary valueForKey:DatabaseField_photo_target]  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }
    
    if ([[photoDictionary  objectForKey:DatabaseField_photo_instrument] isKindOfClass:[NSString class]]){
        photo.instrument = [(NSString *)[photoDictionary valueForKey:DatabaseField_photo_instrument]  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }
    
    if ([[photoDictionary  objectForKey:DatabaseField_photo_url_mid] isKindOfClass:[NSString class]]){
        photo.url = [(NSString *)[photoDictionary valueForKey:DatabaseField_photo_url_mid]  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }

    if ([[photoDictionary  objectForKey:DatabaseField_photo_url_thumb] isKindOfClass:[NSString class]]){
        photo.url_thumb = [(NSString *)[photoDictionary valueForKey:DatabaseField_photo_url_thumb]  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }

    
    [self updateDB];
}

-(Photo *)getPhotoWithID:(NSInteger)_photoID {
    Photo *photo = nil;
    
    // FETCH CLIENTS
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Photo" inManagedObjectContext:self.managedObjectContext];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"id = %@", [NSNumber numberWithInt:_photoID]];
    NSError *error = nil;
    [fetchRequest setEntity:entity];
    [fetchRequest setPredicate:predicate];
    error = nil;
    NSArray *photos = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    // DONT AUTORELEASE fetchRequest
    [fetchRequest release];
    if (photos.count > 0) {
        photo = [photos objectAtIndex:0];
    }
    
    return photo;
}

-(NSArray *)getAllPhotos {
    // FETCH ClientS
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Photo" inManagedObjectContext:self.managedObjectContext];
    NSError *error = nil;
    [fetchRequest setEntity:entity];
    [fetchRequest setPredicate:nil];
    error = nil;

    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"id" ascending:NO] autorelease];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObjects:sortDescriptor, nil]];

    NSArray *photos = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    // DONT AUTORELEASE fetchRequest
    [fetchRequest release];

    return photos;
}


-(NSArray *)getAllPhotosForCategoryID:(NSInteger)categoryID {
    // FETCH ClientS
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Photo" inManagedObjectContext:self.managedObjectContext];
    NSError *error = nil;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"category_id = %@", [NSNumber numberWithInt:categoryID]];
    [fetchRequest setEntity:entity];
    [fetchRequest setPredicate:predicate];
    error = nil;
    
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"id" ascending:NO] autorelease];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObjects:sortDescriptor, nil]];
    
    NSArray *photos = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    // DONT AUTORELEASE fetchRequest
    [fetchRequest release];
    
    return photos;    
}

//-(void)deleteAllClients {
//    NSLog(@"deleteAllClients  ");
//    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Client" inManagedObjectContext:self.managedObjectContext];
//    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
//    NSPredicate *predicate = nil;
//    NSError *error = nil;    
//    [fetchRequest setEntity:entity];
//    [fetchRequest setPredicate:predicate];
//    
//    NSArray *clients = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
//    // DONT AUTORELEASE fetchRequest
//    [fetchRequest release];
//    for (Client *client in clients) {
//        [self.managedObjectContext deleteObject:client];
//        [self updateDB];
//    }
//}
//
//
//-(void)deleteClientWithID:(NSInteger)_clientID {
//    Client *client = [self getClientWithID:_clientID];
//    [self.managedObjectContext deleteObject:client];
//
//    [self updateDB];
//}


-(void)updateDB{
	NSError *error = nil;
	if ([self.managedObjectContext save:&error]) {
	}
}


#pragma mark - 
#pragma mark ---------- MEMORY MANAGEMENT ----------

- (void)dealloc {
	[managedObjectContext release];
    
    [super dealloc];
}
@end
