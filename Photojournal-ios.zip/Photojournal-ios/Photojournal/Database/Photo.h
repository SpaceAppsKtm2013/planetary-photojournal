//
//  Photo.h
//  Photojournal
//
//  Created by samesh on 21/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

// ######################################## DATABASE FIELDS ########################################
#define DatabaseField_photo_id              @"id"
#define DatabaseField_photo_category_id    @"category_id"
#define DatabaseField_photo_title          @"title"
#define DatabaseField_photo_details        @"details"
#define DatabaseField_photo_mission        @"mission"
#define DatabaseField_photo_url            @"url"
#define DatabaseField_photo_url_thumb      @"url_thumb"
#define DatabaseField_photo_url_mid      @"url_mid"
#define DatabaseField_photo_target         @"target"
#define DatabaseField_photo_instrument     @"instrument"

@interface Photo : NSManagedObject

@property (nonatomic, retain) NSNumber * category_id;
@property (nonatomic, retain) NSString * details;
@property (nonatomic, retain) NSNumber * id;
@property (nonatomic, retain) NSString * instrument;
@property (nonatomic, retain) NSString * mission;
@property (nonatomic, retain) NSString * target;
@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSString * url;
@property (nonatomic, retain) NSString * url_thumb;

@end
