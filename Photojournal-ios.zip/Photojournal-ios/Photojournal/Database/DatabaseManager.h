//
//  DatabaseManager.h
//  Clutterly
//
//  Created by Samesh3mikha on 6/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSON.h"
#import "Photo.h"

@interface DatabaseManager : NSObject {
    NSManagedObjectContext *managedObjectContext;
}

//---------  PROPERTIES ---------
@property(nonatomic, retain) NSManagedObjectContext *managedObjectContext;


//---------  CUSTOM METHODS ---------
-(void)parseServerResponseItemsListDictionary:(NSString *)itemsDictionaryResponseString;
-(void)insertItemsToDBFromDictionary:(NSDictionary *)itemsDictionary forOwner:(id)owner;
-(void)insertPhotoInDBWithDictionary:(NSMutableDictionary *)photoDictionary;
//
-(Photo *)getPhotoWithID:(NSInteger)_photoID;
-(NSArray *)getAllPhotos;
-(NSArray *)getAllPhotosForCategoryID:(NSInteger)categoryID;
//-(void)deleteAllClients;
//-(void)deleteClientWithID:(NSInteger)_clientID;
//
-(void)updateDB;

@end
