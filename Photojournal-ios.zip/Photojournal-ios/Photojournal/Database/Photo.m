//
//  Photo.m
//  Photojournal
//
//  Created by samesh on 21/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import "Photo.h"


@implementation Photo

@dynamic category_id;
@dynamic details;
@dynamic id;
@dynamic instrument;
@dynamic mission;
@dynamic target;
@dynamic title;
@dynamic url;
@dynamic url_thumb;

@end
