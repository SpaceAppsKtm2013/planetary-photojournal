//
//  AppDelegate.h
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryListViewController.h"

#define DELEGATE ((AppDelegate*)[[UIApplication sharedApplication] delegate])
#define AppName   @"Photojournal"

@interface AppDelegate : UIResponder <UIApplicationDelegate> {
    UINavigationController *navigationController;
    CategoryListViewController *categoryListViewController;
}

//---------  PROPERTIES ---------
@property (strong, nonatomic) UIWindow *window;
@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) CategoryListViewController *categoryListViewController;


//---------  DEFAULT METHODS ---------
- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

//---------  CUSTOM METHODS ---------
-(void)loadcategoryList;


@end
