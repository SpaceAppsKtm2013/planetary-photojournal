//
//  SharedStore.m
//  StraatJutter
//
//  Created by IphoneMac on 11/11/10.
//  Copyright (c) 2012 __BajraTechnologies__. All rights reserved.
//

#import "SharedStore.h"
#import "AppDelegate.h"

@implementation SharedStore
static SharedStore* _store = nil;

@synthesize checkedConnection, hostActive;
@synthesize categoryArray, categoryOffserKeyArray, categoryPhotosRemainigKeyArray;
@synthesize DBManager;

+(SharedStore*)store
{
	@synchronized([SharedStore class])
	{
		if (!_store)
			_store = [[self alloc] init];
	}
	
    return _store;
}

+(id)alloc
{
	@synchronized([SharedStore class])
	{
		NSAssert(_store == nil, @"Attempted to allocate a second instance of a singleton.");
		_store = [super alloc];
		return _store;
	}
	
	return nil;
}

-(id)init {
	self = [super init];
	if (self != nil) {
		// initialize stuff here
        checkedConnection   = NO;
        hostActive          = NO;
        
        categoryArray = [[NSArray alloc] initWithObjects:
                         @"sun",
                         @"mercury",
                         @"venus",
                         @"earth",
                         @"mars",
                         @"jupiter",
                         @"saturn",
                         @"uranus",
                         @"neptune",
                         @"pluto",
                         @"universe",
                         @"small bodies",
                        nil];
        
        categoryOffserKeyArray = [[NSArray alloc] initWithObjects:
                                  Key_SunPhotosOffset,
                                  Key_MercuryPhotosOffset,
                                  Key_VenusPhotosOffset,
                                  Key_EarthPhotosOffset,
                                  Key_MarsPhotosOffset,
                                  Key_JupiterPhotosOffset,
                                  Key_SaturnPhotosOffset,
                                  Key_UranusPhotosOffset,
                                  Key_NeptunePhotosOffset,
                                  Key_PlutoPhotosOffset,
                                  Key_UniversePhotosOffset,
                                  Key_SmallBodiesPhotosOffset,
                                  nil];
        
        categoryPhotosRemainigKeyArray = [[NSArray alloc] initWithObjects:
                                  Key_SunPhotosRemaining,
                                  Key_MercuryPhotosRemaining,
                                  Key_VenusPhotosRemaining,
                                  Key_EarthPhotosRemaining,
                                  Key_MarsPhotosRemaining,
                                  Key_JupiterPhotosRemaining,
                                  Key_SaturnPhotosRemaining,
                                  Key_UranusPhotosRemaining,
                                  Key_NeptunePhotosRemaining,
                                  Key_PlutoPhotosRemaining,
                                  Key_UniversePhotosRemaining,
                                  Key_SmallBodiesPhotosRemaining,
                                  nil];
        
        DBManager                       = [[DatabaseManager alloc] init];
        DBManager.managedObjectContext  = DELEGATE.managedObjectContext;
        
        secondsIn24Hours = 86400; // 24 * 60 * 60
	}
	   
	return self;
}

#pragma mark -
#pragma mark ---------- CUSTOM METHODS ----------

-(void)setRoundedBorder:(CALayer *)item withRadius:(CGFloat)cornerRadius{
	CALayer *layer = item;
	layer.masksToBounds = YES;
	layer.cornerRadius = cornerRadius;
	layer.borderWidth = 1.5;
	UIColor *grayColor = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:0.5];
	layer.borderColor = [grayColor CGColor];				
}

-(void)setBorderFor:(CALayer *)item withColor:(UIColor*)color width:(CGFloat)borderWidth andRadius:(CGFloat)cornerRadius {
	CALayer *layer = item;
	layer.masksToBounds = YES;
	layer.cornerRadius = cornerRadius;
	layer.borderWidth = borderWidth;
	layer.borderColor = [color CGColor];
}

-(void)setRoundedClearBorder:(CALayer *)item withRadius:(CGFloat)cornerRadius {
	CALayer *layer = item;
	layer.masksToBounds = YES;
	layer.cornerRadius = cornerRadius;
	layer.borderWidth = 1.5;
	layer.borderColor = [[UIColor clearColor] CGColor];
}

- (CGPathRef)renderEllipse:(UIView*)imgView {
    imgView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
	imgView.layer.shadowOpacity = 0.7f;
    imgView.layer.shadowOffset = CGSizeMake(10.0f, 10.0f);
	imgView.layer.shadowRadius = 0.0f;
	imgView.layer.masksToBounds = NO;

	CGSize size = imgView.bounds.size;
	
	CGRect ovalRect = CGRectMake(0.0f, size.height + 5, size.width - 10, 15);
	UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:ovalRect];
	
	return path.CGPath;
}

- (CGPathRef)renderPaperCurl:(UIView*)imgView {
    imgView.layer.shadowColor = [UIColor redColor].CGColor;
	imgView.layer.shadowOpacity = 0.7f;
    imgView.layer.shadowOffset = CGSizeMake(10.0f, 10.0f);
	imgView.layer.shadowRadius = 0.0f;
	imgView.layer.masksToBounds = NO;

	CGSize size = imgView.bounds.size;
	CGFloat curlFactor = 15.0f;
	CGFloat shadowDepth = 5.0f;
    
	UIBezierPath *path = [UIBezierPath bezierPath];
	[path moveToPoint:CGPointMake(0.0f, 0.0f)];
	[path addLineToPoint:CGPointMake(size.width, 0.0f)];
	[path addLineToPoint:CGPointMake(size.width, size.height + shadowDepth)];
	[path addCurveToPoint:CGPointMake(0.0f, size.height + shadowDepth)
			controlPoint1:CGPointMake(size.width - curlFactor, size.height + shadowDepth - curlFactor)
			controlPoint2:CGPointMake(curlFactor, size.height + shadowDepth - curlFactor)];
    
	return path.CGPath;
}

-(void)showToastWithMessage:(NSString *)message {
//    Toast *toast = [[[Toast alloc] initWithMessage:message] autorelease];
//    toast.frame = CGRectMake(20, 300, 280, 50);
//    toast.borderOffset = CGSizeMake(2, 2);
//    toast.tint = ToastColor;
//    toast.toastVisibilityDuration = TOAST_VISIBILITY_DURATION_LONG;
//    [toast showInView: [DELEGATE window]];
}

-(void)showNilDelegateAlertWithMessage:(NSString *)message{
    UIAlertView *alert = [[[UIAlertView alloc] init] autorelease];
	[alert setTitle:nil];
	[alert setMessage:message];
    [alert addButtonWithTitle:@"Ok"];
	[alert setDelegate:nil];
    [alert setTag:0];
	[alert show];
}

-(void)saveImage:(UIImage *)image asFilename:(NSString *)filename{
	NSArray *docpaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [docpaths objectAtIndex:0];
	NSString *imgPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",filename]];
//	[UIImageJPEGRepresentation(image, 0.9) writeToFile:imgPath atomically:YES];
    [UIImagePNGRepresentation(image) writeToFile:imgPath atomically:YES];
    
    NSLog(@"imgPath ==> %@", imgPath);
}

-(void)deleteImageWithFilename:(NSString *)filename {
	NSArray *docpaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [docpaths objectAtIndex:0];
	NSString *imgPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",filename]];
    [[NSFileManager defaultManager] removeItemAtPath:imgPath error:NULL];
    
    NSLog(@"imgPath ==> %@", imgPath);
}

-(NSData *)imageDataForFilename:(NSString *)filename{
	NSArray *docpaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [docpaths objectAtIndex:0];
	NSString *imgPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",filename]];
	UIImage* loadedImage = [UIImage imageWithContentsOfFile:imgPath];
//	NSData *imageData = UIImageJPEGRepresentation(loadedImage, 0.9);
	NSData *imageData = UIImagePNGRepresentation(loadedImage);

	return imageData;
}

- (NSDate*) convertToUTC:(NSDate*)sourceDate {
    NSTimeZone* currentTimeZone = [[[NSTimeZone alloc] init] autorelease];
    NSTimeZone* utcTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    
    NSInteger currentGMTOffset = [currentTimeZone secondsFromGMTForDate:sourceDate];
    NSInteger gmtOffset = [utcTimeZone secondsFromGMTForDate:sourceDate];
    NSTimeInterval gmtInterval = gmtOffset - currentGMTOffset;
    
    NSDate* destinationDate = [[[NSDate alloc] initWithTimeInterval:gmtInterval sinceDate:sourceDate] autorelease];
    
    
//    NSCalendar *gregorian=[[NSCalendar alloc] initWithCalendarIdentifier];
//    [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
//    NSDateComponents *timeZoneComps=[[NSDateComponents alloc] init];
////    [timeZoneComps setHour:16];
//    //specify whatever day, month, and year is appropriate
//    NSDate *destinationDate=[gregorian dateFromComponents:timeZoneComps];
    
    return destinationDate;
}

-(NSDate *)localDateForUTC:(NSDate *)utcDate {
    NSDateFormatter* df_local = [[[NSDateFormatter alloc] init] autorelease];
//    [df_local setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
    [df_local setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString* ts_local_string = [df_local stringFromDate:utcDate];
    
    return [self dateFromString:ts_local_string];
}


-(NSDate *)dateFromString:(NSString*)dateString {
//	dateString = [[dateString stringByReplacingOccurrencesOfString:@"T" withString:@" "] stringByReplacingOccurrencesOfString:@"Z" withString:@" GMT"];
	NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    
    [dateFormatter setTimeZone:gmt];
	[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	NSDate *date = [dateFormatter dateFromString:dateString];
    
    return date;
}

-(NSDate *)weekStartDateForDate:(NSDate *)date {
    NSDate *today = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];// you can use your format.
    
    //Week Start Date    
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    
    int dayofweek = [[[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:today] weekday];// this will give you current day of week
    
    [components setDay:([components day] - ((dayofweek) - 1))];// for beginning of the week.
    
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    NSDateFormatter *dateFormat_first = [[NSDateFormatter alloc] init];
    [dateFormat_first setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString2Prev = [dateFormat stringFromDate:beginningOfWeek];
    
    NSDate *weekstartPrev = [[dateFormat_first dateFromString:dateString2Prev] retain];
    
    return weekstartPrev;
    //Week End Date
    
//    NSCalendar *gregorianEnd = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
//    
//    NSDateComponents *componentsEnd = [gregorianEnd components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
//    
//    int Enddayofweek = [[[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:today] weekday];// this will give you current day of week
//    
//    [componentsEnd setDay:([componentsEnd day]+(7-Enddayofweek)+1)];// for end day of the week
//    
//    NSDate *EndOfWeek = [gregorianEnd dateFromComponents:componentsEnd];
//    NSDateFormatter *dateFormat_End = [[NSDateFormatter alloc] init];
//    [dateFormat_End setDateFormat:@"yyyy-MM-dd"];
//    dateEndPrev = [dateFormat stringFromDate:EndOfWeek];
//    
//    weekEndPrev = [[dateFormat_End dateFromString:dateEndPrev] retain];
//    NSLog(@"%@",weekEndPrev);
}

-(NSString *)stringFromDate:(NSDate*)date usingFormat:(NSString*)format {
	NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormatter setTimeZone:gmt];
	[dateFormatter setDateFormat:format];
    
	NSString *dateString = [dateFormatter stringFromDate:date];

    return dateString;
}

-(NSString *)stringFromDate:(NSDate*)date {
	NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormatter setTimeZone:gmt];
	[dateFormatter setDateFormat:@"MMM dd, yyyy HH:mm"];
    
	NSString *dateString = [dateFormatter stringFromDate:date];
    
    
    return dateString;
}

-(NSString *)stringForDateRangingFrom:(NSDate*)startDate to:(NSDate*)endDate {
    
	NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormatter setTimeZone:gmt];
    
    NSDateComponents *componentsStartDate   = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:startDate];
    NSDateComponents *componentsEndDate     = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:endDate];

    NSMutableString *dateString = [[[NSMutableString alloc] init] autorelease];
    endDate = [endDate dateByAddingTimeInterval:-secondsIn24Hours];
    if ([componentsStartDate year] == [componentsEndDate year]) {
        [dateFormatter setDateFormat:@"dd MMM"];
        [dateString appendString:[dateFormatter stringFromDate:startDate]];
        [dateString appendString:@" - "];
        [dateString appendString:[dateFormatter stringFromDate:endDate]];

        [dateString appendFormat:@", %d", [componentsStartDate year]];
    }
    else {
        [dateFormatter setDateFormat:@"dd MMM, yyyy"];
        [dateString appendString:[dateFormatter stringFromDate:startDate]];
        [dateString appendString:@" - "];
        [dateString appendString:[dateFormatter stringFromDate:endDate]];
    }
    
    return dateString;

}

-(NSString*)stringForTimeDiffFromDate:(NSDate *)refDate {
	NSString *timeInterval;
    NSInteger timeDifference = [[NSDate date] timeIntervalSinceDate:refDate]; //TimeDifference in secs
    if (timeDifference < 0) {
		timeInterval = [NSString stringWithFormat:@"0 %@", NSLocalizedString(@"TimeUnit_Minutes", nil)];
    }
	else if ((timeDifference/60) < 60) {
		timeInterval = [NSString stringWithFormat:@"%d %@", timeDifference/60, NSLocalizedString(@"TimeUnit_Minutes", nil)];
	}
	else {
        if (timeDifference / 3600 == 1) {            
            timeInterval = [NSString stringWithFormat:@"%d %@", timeDifference / 3600, NSLocalizedString(@"TimeUnit_Hour", nil)];
        }
        else {
            timeInterval = [NSString stringWithFormat:@"%d %@", timeDifference / 3600, NSLocalizedString(@"TimeUnit_Hours", nil)];
        }
	}
    
	return timeInterval;
}

-(NSString*)stringInDigitalForTimeDiffFromDate:(NSDate *)refDate {
	NSString *timeInterval;
    NSInteger timeDifference = [[NSDate date] timeIntervalSinceDate:refDate];
    
    if (timeDifference < 0) {
        timeInterval = [NSString stringWithFormat:@"0:0m"];
    }
    else if ((timeDifference/3600) < 1) {
        timeInterval = [NSString stringWithFormat:@"0%d:%dm", timeDifference/3600, (timeDifference%3600)/60];
    }
    else if ((timeDifference/3600) < 10) {
//        timeInterval = [NSString stringWithFormat:@a"0%d:%dm", timeDifference/3600, (timeDifference%3600)/60];
        timeInterval = [NSString stringWithFormat:@"0%d:%d%@", timeDifference/3600, (timeDifference%3600)/60, NSLocalizedString(@"TimeUnit_Hours", nil)];
    }
    else {
        timeInterval = [NSString stringWithFormat:@"%d:%d%@", timeDifference/3600, (timeDifference%3600)/60, NSLocalizedString(@"TimeUnit_Hours", nil)];
    }

    return timeInterval;
}

-(NSString*)firstWordOfString:(NSString*)theStr{
    NSString *firstWord = @"";
    
    NSArray *theWords = [theStr componentsSeparatedByString:@" "];
    if (theWords.count > 0) {
        firstWord = [theWords objectAtIndex:0];
    }
    NSLog(@"firstWord ===> %@", firstWord);

    return firstWord;
}

//-(UIImage *)rotateImage:(UIImage *)image {
////    
////    int orient = image.imageOrientation;
////    
////    UIImageView *imageView = [[[UIImageView alloc] init] autorelease];
////    
////    UIImage *imageCopy = [[UIImage alloc] initWithCGImage:image.CGImage];
////    
////    
////    switch (orient) {
////        case UIImageOrientationLeft:
////            NSLog(@"UIImageOrientationLeft");
////            imageView.transform = CGAffineTransformMakeRotation(0*M_PI);
////            break;
////        case UIImageOrientationRight:
////            NSLog(@"UIImageOrientationRight");
////            imageView.transform = CGAffineTransformMakeRotation(0*M_PI);
////            break;
////        case UIImageOrientationDown: //EXIF = 3
////            NSLog(@"UIImageOrientationDown");
////            imageView.transform = CGAffineTransformMakeRotation(0*M_PI);
////        default:
////            break;
////    }
////    
////    imageView.image = imageCopy;
////    return (imageView.image);
//}

-(UIImage *)rotateImage:(UIImage *)image byDegrees:(CGFloat)degrees
{   
    // calculate the size of the rotated view's containing box for our drawing space
    UIView *rotatedViewBox = [[UIView alloc] initWithFrame:CGRectMake(0,0,image.size.width, image.size.height)];
    CGAffineTransform t = CGAffineTransformMakeRotation(degrees * M_PI / 180);
    rotatedViewBox.transform = t;
    CGSize rotatedSize = rotatedViewBox.frame.size;
    [rotatedViewBox release];
    
    // Create the bitmap context
    UIGraphicsBeginImageContext(rotatedSize);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
    // Move the origin to the middle of the image so we will rotate and scale around the center.
    CGContextTranslateCTM(bitmap, rotatedSize.width/2, rotatedSize.height/2);
    
    //   // Rotate the image context
    CGContextRotateCTM(bitmap, (degrees * M_PI / 180));
    
    // Now, draw the rotated/scaled image into the context
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-image.size.width / 2, -image.size.height / 2, image.size.width, image.size.height), [image CGImage]);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
    
}

-(UIImage *)scaleAndRotateImaga:(UIImage *)image  
{  
    int kMaxResolution = 480; // Or whatever  
    
    CGImageRef imgRef = image.CGImage;  
    
    CGFloat width = CGImageGetWidth(imgRef);  
    CGFloat height = CGImageGetHeight(imgRef);  
    
    CGAffineTransform transform = CGAffineTransformIdentity;  
    CGRect bounds = CGRectMake(0, 0, width, height);  
    if (width > kMaxResolution || height > kMaxResolution) {  
        CGFloat ratio = width/height;  
        if (ratio > 1) {  
            bounds.size.width = kMaxResolution;  
            bounds.size.height = bounds.size.width / ratio;  
        }  
        else {  
            bounds.size.height = kMaxResolution;  
            bounds.size.width = bounds.size.height * ratio;  
        }  
    }  
    
    CGFloat scaleRatio = bounds.size.width / width;  
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));  
    CGFloat boundHeight;  
    UIImageOrientation orient = image.imageOrientation;  
    switch(orient) {  
            
        case UIImageOrientationUp: //EXIF = 1  
            transform = CGAffineTransformIdentity;  
            break;  
            
        case UIImageOrientationUpMirrored: //EXIF = 2  
            transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);  
            transform = CGAffineTransformScale(transform, -1.0, 1.0);  
            break;  
            
        case UIImageOrientationDown: //EXIF = 3  
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);  
            transform = CGAffineTransformRotate(transform, M_PI);  
            break;  
            
        case UIImageOrientationDownMirrored: //EXIF = 4  
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);  
            transform = CGAffineTransformScale(transform, 1.0, -1.0);  
            break;  
            
        case UIImageOrientationLeftMirrored: //EXIF = 5  
            boundHeight = bounds.size.height;  
            bounds.size.height = bounds.size.width;  
            bounds.size.width = boundHeight;  
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);  
            transform = CGAffineTransformScale(transform, -1.0, 1.0);  
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);  
            break;  
            
        case UIImageOrientationLeft: //EXIF = 6  
            boundHeight = bounds.size.height;  
            bounds.size.height = bounds.size.width;  
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);  
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);  
            break;  
            
        case UIImageOrientationRightMirrored: //EXIF = 7  
            boundHeight = bounds.size.height;  
            bounds.size.height = bounds.size.width;  
            bounds.size.width = boundHeight;  
            transform = CGAffineTransformMakeScale(-1.0, 1.0);  
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);  
            break;  
            
        case UIImageOrientationRight: //EXIF = 8  
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;  
            bounds.size.width = boundHeight;  
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);  
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);  
            break;  
            
        default:  
            [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];  
            
    }  
    
    UIGraphicsBeginImageContext(bounds.size);  
    
    CGContextRef context = UIGraphicsGetCurrentContext();  
    
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {  
        CGContextScaleCTM(context, -scaleRatio, scaleRatio);  
        CGContextTranslateCTM(context, -height, 0);  
    }  
    else {  
        CGContextScaleCTM(context, scaleRatio, -scaleRatio);  
        CGContextTranslateCTM(context, 0, -height);  
    }  
    
    CGContextConcatCTM(context, transform);  
    
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);  
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();  
    UIGraphicsEndImageContext();  
    
    return imageCopy;  
}  

-(NSString *)distanceBetweenLocation:(CLLocation*)location1 andLocation:(CLLocation*)location2 {
    NSString *distanceString = @"";
    CGFloat distance  = 0;
    
    distance = [location1 distanceFromLocation:location2] / 1000;
    distanceString = [NSString stringWithFormat:@"%.2f", distance];
    
    return distanceString;
}

@end
