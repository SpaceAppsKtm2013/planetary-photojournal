//
//  SharedStore.h
//  StraatJutter
//
//  Created by Samesh3mikha on 11/11/10.
//  Copyright (c) 2012 __BajraTechnologies__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QuartzCore/QuartzCore.h"
#import <CoreLocation/CoreLocation.h>
//#import "Toast.h"
#import "DatabaseManager.h"


#define developer_version 1

#define IS_IPAD   (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)

#define ScreenSize      [[UIScreen mainScreen] bounds].size
#define StatusbarFrame  CGRectMake(0, 0, 320, 20)

#define Color_AppTheme [UIColor colorWithRed:7.0/255 green:75.0/255 blue:210.0/255 alpha:1]

// ######################################## IMAGES ########################################
#define Image_AppLogo   @"AppLogo.png"

#define Image_TitleBG @"TitleBG.png"
#define Image_CellBG @"CellBG.png"
#define Image_DetailsBG @"DetailsBG.png"
#define Image_UpArrow @"UpArrow.png"
#define Image_DownArrow @"DownArrow.png"


#define Image_MenuButtonEarth @"MenuButtonEarth.png"
#define Image_MenuButtonJupiter @"MenuButtonJupiter.png"
#define Image_MenuButtonMars @"MenuButtonMars.png"
#define Image_MenuButtonMercury @"MenuButtonMercury.png"
#define Image_MenuButtonNeptune @"MenuButtonNeptune.png"
#define Image_MenuButtonPluto @"MenuButtonPluto.png"
#define Image_MenuButtonSaturn @"MenuButtonSaturn.png"
#define Image_MenuButtonSmallbodies @"MenuButtonSmallbodies.png"
#define Image_MenuButtonSun @"MenuButtonSun.png"
#define Image_MenuButtonUniverse @"MenuButtonUniverse.png"
#define Image_MenuButtonUranus @"MenuButtonUranus.png"
#define Image_MenuButtonVenus @"MenuButtonVenus.png"
#define Image_BackButton @"BackButton.png"
#define Image_ListViewButton @"ListViewButton.png"


// ######################################## WEB API PARAMS KEYS ########################################
//CLIENT LIST
#define ParamsKey_photos                       @"photos"
#define ParamsKey_photo                        @"photo"
#define ParamsKey_photo_id                     @"client_id"
#define ParamsKey_description                   @"description"
#define ParamsKey_remaining                    @"remaining"


// ######################################## KEYS FOR VALUE STORING ########################################

#define Key_SunPhotosOffset @"SunPhotosOffset"
#define Key_MercuryPhotosOffset @"MercuryPhotosOffset"
#define Key_VenusPhotosOffset @"VenusPhotosOffset"
#define Key_EarthPhotosOffset @"EarthPhotosOffset"
#define Key_MarsPhotosOffset @"MarsPhotosOffset"
#define Key_JupiterPhotosOffset @"JupiterPhotosOffset"
#define Key_SaturnPhotosOffset @"SaturnPhotosOffset"
#define Key_UranusPhotosOffset @"UranusPhotosOffset"
#define Key_NeptunePhotosOffset @"NeptunePhotosOffset"
#define Key_PlutoPhotosOffset @"PlutoPhotosOffset"
#define Key_UniversePhotosOffset @"UniversePhotosOffset"
#define Key_SmallBodiesPhotosOffset @"SmallBodiesPhotosOffset"

#define Key_SunPhotosRemaining @"SunPhotosRemaining"
#define Key_MercuryPhotosRemaining @"MercuryPhotosRemaining"
#define Key_VenusPhotosRemaining @"VenusPhotosRemaining"
#define Key_EarthPhotosRemaining @"EarthPhotosRemaining"
#define Key_MarsPhotosRemaining @"MarsPhotosRemaining"
#define Key_JupiterPhotosRemaining @"JupiterPhotosRemaining"
#define Key_SaturnPhotosRemaining @"SaturnPhotosRemaining"
#define Key_UranusPhotosRemaining @"UranusPhotosRemaining"
#define Key_NeptunePhotosRemaining @"NeptunePhotosRemaining"
#define Key_PlutoPhotosRemaining @"PlutoPhotosRemaining"
#define Key_UniversePhotosRemaining @"UniversePhotosRemaining"
#define Key_SmallBodiesPhotosRemaining @"SmallBodiesPhotosRemaining"


// ######################################## HANDLING LOGS ########################################
NSTimeInterval secondsIn24Hours;

typedef enum {
    category_sun            = 0,
    category_mercury        = 1,
    category_venus          = 2,
    category_earth          = 3,
    category_mars           = 4,
    category_jupiter        = 5,
    category_saturn         = 6,
    category_uranus         = 7,
    category_neptune        = 8,
    category_pluto          = 9,
    category_universe       = 10,
    category_smallbodies    = 11,
} Categories;

@interface SharedStore : NSObject {
    BOOL checkedConnection;
    BOOL hostActive;
    
    NSArray *categoryArray;
    NSArray *categoryOffserKeyArray;
    NSArray *categoryPhotosRemainigKeyArray;
    
    DatabaseManager *DBManager;
}

+(SharedStore*)store;

//---------  PROPERTIES ---------
@property (nonatomic, assign) BOOL checkedConnection;
@property (nonatomic, assign) BOOL hostActive;
@property (nonatomic, retain) NSArray *categoryArray;
@property (nonatomic, retain) NSArray *categoryOffserKeyArray;
@property (nonatomic, retain) NSArray *categoryPhotosRemainigKeyArray;
@property (nonatomic, retain) DatabaseManager *DBManager;

//---------  CUSTOM METHODS ---------
-(void)setRoundedBorder:(CALayer *)item withRadius:(CGFloat)cornerRadius;
-(void)setRoundedClearBorder:(CALayer *)item withRadius:(CGFloat)cornerRadius;
-(void)setBorderFor:(CALayer *)item withColor:(UIColor*)color width:(CGFloat)borderWidth andRadius:(CGFloat)cornerRadius;
- (CGPathRef)renderEllipse:(UIView*)imgView;
- (CGPathRef)renderPaperCurl:(UIView*)imgView;

-(void)saveImage:(UIImage *)image asFilename:(NSString *)filename;
-(void)deleteImageWithFilename:(NSString *)filename;
-(NSData *)imageDataForFilename:(NSString *)filename;
-(NSDate*) convertToUTC:(NSDate*)sourceDate;
-(NSDate *)localDateForUTC:(NSDate *)utcDate;
-(NSDate *)dateFromString:(NSString*)dateString;
-(NSDate *)weekStartDateForDate:(NSDate *)date;
-(NSString *)stringFromDate:(NSDate*)date usingFormat:(NSString*)format;
-(NSString *)stringForDateRangingFrom:(NSDate*)startDate to:(NSDate*)endDate;
-(NSString *)stringFromDate:(NSDate*)date;
-(NSString*)stringForTimeDiffFromDate:(NSDate *)refDate;
-(NSString*)stringInDigitalForTimeDiffFromDate:(NSDate *)refDate; 
-(NSString*)firstWordOfString:(NSString*)theStr;
//-(UIImage *)rotateImage:(UIImage *)image ;
-(UIImage *)rotateImage:(UIImage *)image byDegrees:(CGFloat)degrees;
-(UIImage *)scaleAndRotateImaga:(UIImage *)image;
-(void)showToastWithMessage:(NSString *)message;
-(void)showNilDelegateAlertWithMessage:(NSString *)message;

-(NSString *)distanceBetweenLocation:(CLLocation*)location1 andLocation:(CLLocation*)location2;

@end
