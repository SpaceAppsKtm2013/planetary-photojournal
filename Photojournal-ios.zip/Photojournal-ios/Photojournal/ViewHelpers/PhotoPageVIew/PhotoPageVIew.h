//
//  PhotoPageVIew.h
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Photo.h"
#import "PhotojournalWebAPI.h"

@interface PhotoPageVIew : UIView <PhotojournalWebAPIDelegate> {
    UIImageView *photoImageView;
    UIView *detailsContainerView;
    UIImageView *detailsBGImageView;
    UIScrollView *detailsContainerScrollView;
    UILabel *titleLabel;
    UILabel *detailsLabel;
    UILabel *targetLabel;
    UILabel *missionLabel;
    UILabel *instrumentLabel;
    UIButton *showHideButton;
    UIActivityIndicatorView *imageLoadingActivityIndicator;
    
    Photo *photo;
    NSInteger photoID;
    BOOL imageLoaded;
    
    PhotojournalWebAPI *webAPIForImageRetrieving;
}
//---------  PROPERTIES ---------
@property(nonatomic, retain) UIImageView *photoImageView;
@property(nonatomic, retain) UIView *detailsContainerView;
@property(nonatomic, retain) UIImageView *detailsBGImageView;
@property(nonatomic, retain) UIScrollView *detailsContainerScrollView;
@property(nonatomic, retain) UILabel *titleLabel;
@property(nonatomic, retain) UILabel *detailsLabel;
@property(nonatomic, retain) UILabel *targetLabel;
@property(nonatomic, retain) UILabel *missionLabel;
@property(nonatomic, retain) UILabel *instrumentLabel;
@property(nonatomic, retain) UIButton *showHideButton;
@property(nonatomic, retain) UIActivityIndicatorView *imageLoadingActivityIndicator;
@property(nonatomic, retain) Photo *photo;
@property(nonatomic, assign) NSInteger photoID;
@property(nonatomic, retain) PhotojournalWebAPI *webAPIForImageRetrieving;


//---------  CUSTOM METHODS ---------
-(void)customizeViewForPhoto:(Photo*)_photo;

-(void)getImageFromServer;


@end
