//
//  PhotoPageVIew.m
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import "PhotoPageVIew.h"

@implementation PhotoPageVIew

@synthesize photoImageView;
@synthesize detailsContainerView, detailsBGImageView, detailsContainerScrollView;
@synthesize titleLabel, detailsLabel;
@synthesize targetLabel, missionLabel, instrumentLabel;
@synthesize showHideButton;
@synthesize imageLoadingActivityIndicator;
@synthesize photo, photoID;
@synthesize webAPIForImageRetrieving;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        imageLoaded = NO;
        frame.origin = CGPointMake(0, 0);
        photoImageView = [[UIImageView alloc] initWithFrame:frame];
        detailsContainerView = [[UIView alloc] init];
        showHideButton = [[UIButton alloc] init];
        detailsBGImageView = [[UIImageView alloc] init];
        detailsContainerScrollView = [[UIScrollView alloc] init];
        titleLabel = [[UILabel alloc] init];
        detailsLabel = [[UILabel alloc] init];
        targetLabel = [[UILabel alloc] init];
        missionLabel = [[UILabel alloc] init];
        instrumentLabel = [[UILabel alloc] init];
        imageLoadingActivityIndicator = [[UIActivityIndicatorView alloc] init];
        
        webAPIForImageRetrieving = [[PhotojournalWebAPI alloc] init];
        webAPIForImageRetrieving.delegate = self;
        
        photoImageView.contentMode = UIViewContentModeScaleAspectFit;


    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(IBAction)showHideDetailsView:(id)sender {
    detailsContainerView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.0, 1.0);
    
    CGRect viewFrame = self.detailsContainerView.frame;
    
    if (viewFrame.size.height == 32) {
        viewFrame = CGRectMake(0, self.frame.size.height - 215, ScreenSize.width, 215);
        [showHideButton setImage:[UIImage imageNamed:Image_DownArrow] forState:UIControlStateNormal];

//        detailsContainerView.frame = frame;
    }
    else {
        [showHideButton setImage:[UIImage imageNamed:Image_UpArrow] forState:UIControlStateNormal];
        viewFrame.origin.y = viewFrame.origin.y + viewFrame.size.height-32;
        viewFrame.size.height = 32;
    }
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    [UIView setAnimationDelay:0.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    self.detailsContainerView.frame = viewFrame;
    
    [UIView commitAnimations];
}


#pragma mark -
#pragma mark ---------- URLCONNECTION METHODS ----------
-(void)getImageFromServer {
    if (imageLoaded)  return;
    [imageLoadingActivityIndicator startAnimating];
    [webAPIForImageRetrieving getImageFromUrl:photo.url];
}

#pragma mark -
#pragma mark ---------- WebAPIDelegate DELEGATE METHODS ----------
-(void)imageRetreivingFailedWithError:(NSError *)error {
	[imageLoadingActivityIndicator stopAnimating];
}

-(void)imageRetreivingCompletedWithResponse:(NSData *)responseData {
    [imageLoadingActivityIndicator stopAnimating];
    
    
    imageLoaded = YES;
    // Set appIcon and clear temporary data/image
	UIImage *image = [[[UIImage alloc] initWithData:responseData] autorelease];
    if (image) {

        self.photoImageView.image = image;
    }
}


#pragma mark -
#pragma mark ---------- CUSTOM METHODS ----------

-(void)customizeViewForPhoto:(Photo*)_photo {
    self.photo = _photo;
    photoID = [photo.id integerValue];
    
    [self addSubview:photoImageView];
    [self addSubview:detailsContainerView];
    [detailsContainerView addSubview:detailsBGImageView];
    [detailsContainerView addSubview:showHideButton];
    [detailsContainerView addSubview:detailsContainerScrollView];
    [detailsContainerScrollView addSubview:titleLabel];
    [detailsContainerScrollView addSubview:detailsLabel];
    [detailsContainerScrollView addSubview:targetLabel];
    [detailsContainerScrollView addSubview:missionLabel];
    [detailsContainerScrollView addSubview:instrumentLabel];
    [self addSubview:imageLoadingActivityIndicator];
    
    CGRect frame = CGRectMake(0, self.frame.size.height - 215, ScreenSize.width, 215);
    detailsContainerView.frame = frame;
    [detailsContainerView setBackgroundColor:[UIColor clearColor]];
    
    frame = CGRectMake(0, 0, detailsContainerView.frame.size.width, detailsContainerView.frame.size.height);
    detailsBGImageView.frame = frame;
    [detailsBGImageView setImage:[UIImage imageNamed:Image_DetailsBG]];
    
    [showHideButton setFrame:CGRectMake(ScreenSize.width/2-30, 0, 60, 34)];
    [showHideButton setImage:[UIImage imageNamed:Image_DownArrow] forState:UIControlStateNormal];
    [showHideButton addTarget:self action:@selector(showHideDetailsView:) forControlEvents:UIControlEventTouchUpInside];
    [self.detailsContainerView addSubview:showHideButton];

    frame = CGRectMake(0, 35, detailsContainerView.frame.size.width, detailsContainerView.frame.size.height - 35);
    detailsContainerScrollView.frame = frame;

    NSInteger yPosition = 5;
    titleLabel.text = photo.title;
    [titleLabel setFont:[UIFont fontWithName:@"Avenir Next Condensed Bold" size:17.0f]];
    titleLabel.frame = CGRectMake(5, yPosition, ScreenSize.width-10, 21);
    titleLabel.numberOfLines = 0;
    [titleLabel sizeToFit];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textColor = [UIColor whiteColor];

    yPosition += (titleLabel.frame.size.height + 5);
    [targetLabel setFont:[UIFont fontWithName:@"Avenir Next Condensed Demi Bold" size:14.0f]];
    targetLabel.text = [NSString stringWithFormat:@"Target : %@", photo.target];
    targetLabel.frame = CGRectMake(5, yPosition, ScreenSize.width-10, 21);
    targetLabel.numberOfLines = 0;
    [targetLabel sizeToFit];
    targetLabel.backgroundColor = [UIColor clearColor];
    targetLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    
    yPosition += (targetLabel.frame.size.height + 2);
    [missionLabel setFont:[UIFont fontWithName:@"Avenir Next Condensed Bold" size:14.0f]];
    missionLabel.text = [NSString stringWithFormat:@"Mission : %@", photo.mission];
    missionLabel.frame = CGRectMake(5, yPosition, ScreenSize.width-10, 21);
    missionLabel.numberOfLines = 0;
    [missionLabel sizeToFit];
    missionLabel.backgroundColor = [UIColor clearColor];
    missionLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    
    yPosition += (missionLabel.frame.size.height + 2);
    [instrumentLabel setFont:[UIFont fontWithName:@"Avenir Next Condensed Bold" size:14.0f]];
    instrumentLabel.text = [NSString stringWithFormat:@"Instrument : %@", photo.instrument];
    instrumentLabel.frame = CGRectMake(5, yPosition, ScreenSize.width-10, 21);
    instrumentLabel.numberOfLines = 0;
    [instrumentLabel sizeToFit];
    instrumentLabel.backgroundColor = [UIColor clearColor];
    instrumentLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    
    yPosition += (instrumentLabel.frame.size.height + 5);
    [detailsLabel setFont:[UIFont fontWithName:@"Avenir Next Condensed Bold" size:14.0f]];
    detailsLabel.text = photo.details;
    detailsLabel.frame = CGRectMake(5, yPosition, ScreenSize.width-10, 21);
    detailsLabel.numberOfLines = 0;
    [detailsLabel sizeToFit];
    detailsLabel.backgroundColor = [UIColor clearColor];
    detailsLabel.textColor = [UIColor whiteColor];
    
    [detailsContainerScrollView setContentSize:CGSizeMake(detailsContainerScrollView.frame.size.width, yPosition + detailsLabel.frame.size.height + 10)];
    
    imageLoadingActivityIndicator.hidesWhenStopped = YES;
    imageLoadingActivityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
    imageLoadingActivityIndicator.center = CGPointMake(ScreenSize.width/2, 100);
    
//    [self getImageFromServer];
//    photoImageView.image = [UIImage imageNamed:@"detail_screen_text.png"];
}


#pragma mark -
#pragma mark ---------- MEMORY MANAGEMENT ----------

- (void)dealloc {
    [photoImageView release];
    [detailsContainerView release];
    [detailsContainerScrollView release];
    [titleLabel release];
    [detailsLabel release];
    [targetLabel release];
    [missionLabel release];
    [instrumentLabel release];
    [showHideButton release];
    [imageLoadingActivityIndicator release];
    
    [photo release];
    
    if (webAPIForImageRetrieving) {
        [webAPIForImageRetrieving cancelAllConnections];
    }
    webAPIForImageRetrieving.delegate = nil;
    [webAPIForImageRetrieving release];
    
    [super dealloc];
}

@end
