//
//  PhotoListTableViewCell.h
//  Clutterly
//
//  Created by Samesh3mikha on 23/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoListTableViewCell : UITableViewCell {
    IBOutlet UIImageView *imageView;
    IBOutlet UILabel *titleLabel;
    IBOutlet UILabel *detailLabel;
    IBOutlet UIActivityIndicatorView *activityIndicator;
} 

@property (nonatomic, retain) IBOutlet UIImageView *imageView;
@property (nonatomic, retain) IBOutlet UILabel *titleLabel;
@property (nonatomic, retain) IBOutlet UILabel *detailLabel;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *activityIndicator;

@end
