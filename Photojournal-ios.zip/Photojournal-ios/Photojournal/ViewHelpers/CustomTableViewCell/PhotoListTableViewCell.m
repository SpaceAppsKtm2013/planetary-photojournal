//
//  PhotoListTableViewCell.m
//  Clutterly
//
//  Created by Samesh3mikha on 23/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "PhotoListTableViewCell.h"

@implementation PhotoListTableViewCell

@synthesize imageView, titleLabel, detailLabel, activityIndicator;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark - 
#pragma mark ---------- MEMORY MANAGEMENT ----------

- (void)dealloc {
	[imageView release];
	[titleLabel release];
	[detailLabel release];
    [activityIndicator release];

    [super dealloc];
}

@end
