//
//  PhotosViewController.h
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhotojournalWebAPI.h"
#import "Photo.h"
#import "PhotoListTableViewCell.h"
#import "IconDownloader.h"
#import "PhotoPagesViewController.h"

@interface PhotosViewController : UIViewController <PhotojournalWebAPIDelegate, UITableViewDataSource, UITableViewDelegate, NSFetchedResultsControllerDelegate, IconDownloaderDelegate> {
    IBOutlet UITableView *photoListTableView;
    
    Categories category;
    NSInteger numItemsLoaded;
    BOOL fetchingPhotos;

    NSMutableDictionary *itemsImage;
	NSMutableDictionary *imageDownloadsInProgress;

    NSFetchedResultsController *fetchedResultsController;

    PhotojournalWebAPI *photojournalWebAPIForPhotosRettrieving;
}
//---------  PROPERTIES ---------
@property(nonatomic, retain) IBOutlet UITableView *photoListTableView;
@property(nonatomic, assign) Categories category;
@property(nonatomic, assign) NSInteger numItemsLoaded;
@property(nonatomic, assign) BOOL fetchingPhotos;
@property(nonatomic, retain) NSMutableDictionary *itemsImage;
@property(nonatomic, retain) NSMutableDictionary *imageDownloadsInProgress;
@property(nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@property(nonatomic, retain) PhotojournalWebAPI *photojournalWebAPIForPhotosRettrieving;

//---------  SELF METHODS ---------
-(id)initWithCategoryID:(NSInteger)categoryID;

//---------  IBACTION METHODS ---------
-(IBAction)backButtonClicked:(UIButton *)button ;

//---------  URLCONNECTION METHODS ---------
-(void)getPhotosFromServer;

//---------  CUSTOM METHODS ---------
-(void)customizeView;
-(void)startIconDownloadForPhoto:(Photo *)photo;
-(void)cancelIconDownloadForPhoto:(Photo *)photo;
-(void)showImagesForPhoto:(Photo *)photo;


@end
