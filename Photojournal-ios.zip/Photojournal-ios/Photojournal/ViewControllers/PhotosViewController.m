//
//  PhotosViewController.m
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import "PhotosViewController.h"
#import "AppDelegate.h"

@interface PhotosViewController ()

@end

@implementation PhotosViewController

@synthesize photoListTableView;
@synthesize category;
@synthesize numItemsLoaded, fetchingPhotos;
@synthesize itemsImage, imageDownloadsInProgress;
@synthesize fetchedResultsController;
@synthesize photojournalWebAPIForPhotosRettrieving;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}


-(id)initWithCategoryID:(NSInteger)categoryID {
    self = [super init];
    if(self){
        // Custom initialization
        category = categoryID;
        
        fetchingPhotos = YES;
        numItemsLoaded = 0;
        
        self.imageDownloadsInProgress = [NSMutableDictionary dictionary];
		self.itemsImage = [NSMutableDictionary dictionary];
        
        photojournalWebAPIForPhotosRettrieving = [[PhotojournalWebAPI alloc] init];
        photojournalWebAPIForPhotosRettrieving.delegate = self;
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    // Do any additional setup after loading the view from its nib.
    [self customizeView];
    [self getPhotosFromServer];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Start listening for updates when visible
    self.fetchedResultsController.delegate = self;
}


#pragma mark -
#pragma mark ---------- IBACTION METHODS ----------

-(IBAction)backButtonClicked:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark ---------- UITABLEVIEW DEFAULT METHODS ----------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return [[self.fetchedResultsController sections] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    id <NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
    NSInteger numExtraCell = 0;
    
    // SHOW EXTRA CELL AT BOTTOM IF THERE ARE ITEMS LEFT TO BE PULLED FROM SERVER
    if (fetchingPhotos) {
        numExtraCell = 1;
    }
    
    numItemsLoaded = [sectionInfo numberOfObjects];

    return [sectionInfo numberOfObjects] + numExtraCell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger rowHeight = 80;
    if (IS_IPAD) {
        rowHeight = 150;
    }
    
	return rowHeight;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(PhotoListTableViewCell *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"PhotoListTableViewCell";
    
    PhotoListTableViewCell *cell = (PhotoListTableViewCell *)[photoListTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
		NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"PhotoListTableViewCell" owner:nil options:nil];
		for (id currentObject in topLevelObjects) {
			if([currentObject isKindOfClass:[UITableViewCell class]]){
				cell = (PhotoListTableViewCell *) currentObject;
			}
		}
    }
    
    
    // samesh
    //    cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    NSInteger rowsAmount = [photoListTableView numberOfRowsInSection:[indexPath section]];
    if (fetchingPhotos  && [indexPath row] == rowsAmount - 1) {
        // This is the last cell in the table
        cell.imageView.hidden = YES;
        cell.titleLabel.text = @"  Fetching items....";
        cell.detailLabel.text = @"";
        [cell.activityIndicator startAnimating];
        cell.accessoryType = UITableViewCellAccessoryNone;
        
        [self getPhotosFromServer];
    }
    else {
        // Configure the cell...
        [self configureCell:cell atIndexPath:indexPath];
        cell.imageView.hidden = NO;
        [cell.activityIndicator stopAnimating];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    
	return cell;
}

-(void)configureCell:(PhotoListTableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath{
    Photo *photo = [self.fetchedResultsController objectAtIndexPath:indexPath];
    cell.titleLabel.text = photo.title;
    cell.detailLabel.text = @"";
    
    [[SharedStore store] setRoundedBorder:[cell.imageView layer] withRadius:4.0];
    if ([itemsImage objectForKey:photo.id])
	{
        cell.imageView.image = [itemsImage objectForKey:photo.id];
    }
    else {
        cell.imageView.image = nil;
        [self startIconDownloadForPhoto:photo];
    }
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (!fetchingPhotos || [indexPath row] != [photoListTableView numberOfRowsInSection:[indexPath section]] - 1) {
        return indexPath;
	}
    
	return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    PhotoPagesViewController *photoPagesViewController = [[[PhotoPagesViewController alloc] initWithCategoryID:category forPage:indexPath.row] autorelease];
    [self.navigationController pushViewController:photoPagesViewController animated:YES];
}

#pragma mark -
#pragma mark ---------- FETCHEDRESULTSCONTROLER delegate methods ----------

//override fetchedResultsController getter
- (NSFetchedResultsController *)fetchedResultsController {
	if (fetchedResultsController == nil) {
		NSFetchRequest *fetchRequest = [[[NSFetchRequest alloc] init] autorelease];
		NSEntityDescription *entity = [NSEntityDescription entityForName:@"Photo" inManagedObjectContext:DELEGATE.managedObjectContext];
        NSPredicate *predicate = nil;
        predicate = [NSPredicate predicateWithFormat:@"category_id = %@", [NSNumber numberWithInt:category]];

        [fetchRequest setFetchBatchSize:20];
		[fetchRequest setEntity:entity];
        [fetchRequest setPredicate:predicate];
        
        NSSortDescriptor *sortDescriptor;
        sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"id" ascending:NO] autorelease];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObjects:sortDescriptor, nil]];
		
		fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:DELEGATE.managedObjectContext sectionNameKeyPath:nil cacheName:nil];
		fetchedResultsController.delegate = self;
		NSError *error = nil;
		if (![fetchedResultsController performFetch:&error]) {
			//handle the error...
			NSLog(@"error occured in fetched result controller");
		}
	}
	return fetchedResultsController;
}

- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
	[self.photoListTableView beginUpdates];
}

- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo
		   atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
	
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.photoListTableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
			
        case NSFetchedResultsChangeDelete:
            [self.photoListTableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}

- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(NSIndexPath *)indexPath
	 forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(NSIndexPath *)newIndexPath {
	switch(type) {
		case NSFetchedResultsChangeUpdate:
			[self configureCell:(PhotoListTableViewCell *)[self.photoListTableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
			break;
			
		case NSFetchedResultsChangeMove:
			[self.photoListTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
			[self.photoListTableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
			break;
			
		case NSFetchedResultsChangeInsert:
			[self.photoListTableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationRight];
			break;
			
		case NSFetchedResultsChangeDelete:
			[self.photoListTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
			break;
	}
}

- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
	[self.photoListTableView endUpdates];
}


#pragma mark -
#pragma mark ---------- URLCONNECTION METHODS ----------
-(void)getPhotosFromServer {
//    if (![SharedStore store].hostActive) {
//        NSLog(@"DONT getPhotosFromServer");
//        fetchingPhotos = NO;
//        [self.photoListTableView reloadData];        
//        return;
//    }

    NSLog(@"getPhotosFromServer");
    [photojournalWebAPIForPhotosRettrieving getPhotoListForID:category WhenOffset:numItemsLoaded inNumber:20];
}

#pragma mark -
#pragma mark ---------- ClutterlyWebAPIDelegate DELEGATE METHODS ----------

-(void)photosRetreivingFailedWithError:(NSError *)error {
    NSLog(@"photosRetreivingFailedWithError");
    fetchingPhotos = NO;
    [self.photoListTableView reloadData];

}

-(void)photosRetreivingCompletedWithResponse:(NSData *)responseData {
    NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
    NSDictionary *responseDictionary = [[[NSDictionary alloc] initWithDictionary:[responseString JSONValue]] autorelease];
    
    NSLog(@"responseDictionary ===> %@", responseDictionary);

    if ([[responseDictionary valueForKey:ParamsKey_photos] isKindOfClass:[NSArray class]]) {
        [[SharedStore store].DBManager parseServerResponseItemsListDictionary:responseString];
    }
    else {
    }
}


#pragma mark -
#pragma mark ---------- ICONDOWNLOADER DELEGATE METHODS ----------

// called by our ImageDownloader when an icon is ready to be displayed
- (void)appImageDidLoad:(NSInteger)ownerID
{
    NSLog(@"appImageDidLoad ------");
    Photo *photo = [[SharedStore store].DBManager getPhotoWithID:ownerID];
    NSLog(@"Photo = %@", photo);
    
    IconDownloader *iconDownloader = [imageDownloadsInProgress objectForKey:photo.id];
    if (iconDownloader != nil)
    {
        // Display the newly loaded image
        if (iconDownloader.downloadedImage) {
            [itemsImage setObject:iconDownloader.downloadedImage forKey:photo.id];
        }
        else {
//            UIImage *tempImage = [UIImage imageNamed:@"noImage.png"];
//            [itemsImage setObject:tempImage forKey:photo.id];
        }
        
		[self showImagesForPhoto:photo];
    }	
}

#pragma mark -
#pragma mark ---------- CUSTOM METHODS ----------
-(void)customizeView {
    [self.photoListTableView setBackgroundColor:[UIColor clearColor]];
    NSLog(@"MAchikne ----");
}

-(void)startIconDownloadForPhoto:(Photo *)photo {
    IconDownloader *iconDownloader = [imageDownloadsInProgress objectForKey:photo.id];
    if (iconDownloader == nil)
    {
        iconDownloader = [[[IconDownloader alloc] init] autorelease];
		iconDownloader.ownerID = [photo.id intValue];
        iconDownloader.imageURL = photo.url_thumb;
        iconDownloader.delegate = self;
        [imageDownloadsInProgress setObject:iconDownloader forKey:photo.id];
        [iconDownloader startDownload];
    }
}

-(void)cancelIconDownloadForPhoto:(Photo *)photo {
    IconDownloader *iconDownloader = [imageDownloadsInProgress objectForKey:photo.id];
    if (iconDownloader != nil)
    {
		if (iconDownloader.connectionImage != nil) {
			[iconDownloader cancelDownload];
		}
		[imageDownloadsInProgress removeObjectForKey:photo.id];
    }
}

// Load downloaded Image into UIImageView
-(void)showImagesForPhoto:(Photo *)photo {
	NSIndexPath *indexPath =  [self.fetchedResultsController indexPathForObject:photo];
	PhotoListTableViewCell *cell = (PhotoListTableViewCell *)[self.photoListTableView cellForRowAtIndexPath:indexPath];
    
	if ([itemsImage objectForKey:photo.id])
	{
		cell.imageView.image = [itemsImage objectForKey:photo.id];
	}
	else
	{
		[self startIconDownloadForPhoto:photo];
	}
}


#pragma mark -
#pragma mark ---------- MEMORY MANAGEMENT ----------

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(void)viewWillDisappear:(BOOL)animated {
    self.fetchedResultsController.delegate = nil;
    
    [super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    self.fetchedResultsController.delegate = nil;
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [photoListTableView release];
    
    [itemsImage release];
    for (id key in imageDownloadsInProgress) {
		IconDownloader *iconDownloader = [imageDownloadsInProgress objectForKey:key];
		if (iconDownloader != nil) {
			if (iconDownloader.connectionImage != nil) {
				[iconDownloader cancelDownload];
				iconDownloader = nil;
			}
		}
	}
    [imageDownloadsInProgress release];

    self.fetchedResultsController.delegate = nil;
    [fetchedResultsController release]; //samesh
    
    if (photojournalWebAPIForPhotosRettrieving) {
        [photojournalWebAPIForPhotosRettrieving cancelAllConnections];
    }
    photojournalWebAPIForPhotosRettrieving.delegate = nil;
    [photojournalWebAPIForPhotosRettrieving release];

    
    [super dealloc];
}

@end
