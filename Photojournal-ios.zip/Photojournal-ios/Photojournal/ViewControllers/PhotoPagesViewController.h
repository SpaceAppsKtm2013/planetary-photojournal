//
//  PhotoPagesViewController.h
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhotojournalWebAPI.h"
#import "Photo.h"
#import "PhotoPageVIew.h"

@interface PhotoPagesViewController : UIViewController <PhotojournalWebAPIDelegate, UIScrollViewDelegate> {
    IBOutlet UIScrollView *scrollView;
    IBOutlet UIPageControl *pageControl;
    IBOutlet UILabel *pageIndicatorLabel;
    
    Categories category;
    NSMutableArray *photosArray;
    NSInteger numItemsLoaded;
    BOOL fetchingPhotos;
    BOOL pageControlBeingUsed;
    NSInteger currentPage;
    
    PhotojournalWebAPI *photojournalWebAPIForPhotosRettrieving;
}
//---------  PROPERTIES ---------
@property(nonatomic, retain) IBOutlet UIScrollView *scrollView;
@property(nonatomic, retain) IBOutlet UIPageControl *pageControl;
@property(nonatomic, retain) IBOutlet UILabel *pageIndicatorLabel;
@property(nonatomic, assign) Categories category;
@property(nonatomic, retain) NSMutableArray *photosArray;
@property(nonatomic, assign) NSInteger numItemsLoaded;
@property(nonatomic, assign) BOOL fetchingPhotos;
@property(nonatomic, assign) NSInteger currentPage;
@property(nonatomic, retain) PhotojournalWebAPI *photojournalWebAPIForPhotosRettrieving;


//---------  SELF METHODS ---------
-(id)initWithCategoryID:(NSInteger)categoryID forPage:(NSInteger)_currentPage;

// ---------- IBACTION METHODS ----------
-(IBAction)backButtonClicked:(UIButton *)button ;
-(IBAction)previousPageButtonClicked:(UIButton *)button ;
-(IBAction)nextPageButtonClicked:(UIButton *)button ;
- (IBAction)changePage;


//---------  URLCONNECTION METHODS ---------
-(void)getPhotosFromServer;

//---------  CUSTOM METHODS ---------
-(void)customizeView;
-(void)fillPages;
-(void)gotoPage:(NSInteger)pageNo;
-(void)loadImageForPage:(NSInteger)pageNo;

@end
