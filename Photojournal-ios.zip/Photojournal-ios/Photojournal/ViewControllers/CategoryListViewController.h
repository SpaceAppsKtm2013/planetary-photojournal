//
//  CategoryListViewController.h
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhotosViewController.h"

@interface CategoryListViewController : UIViewController {
}

//---------  PROPERTIES ---------

//---------  IBACTION METHODS ---------
-(IBAction)menuButtonClicked:(UIButton *)button ;

//---------  CUSTOM METHODS ---------
-(void)customizeView;


@end
