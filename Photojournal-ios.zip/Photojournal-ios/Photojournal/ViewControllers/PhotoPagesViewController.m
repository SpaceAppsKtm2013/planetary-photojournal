//
//  PhotoPagesViewController.m
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import "PhotoPagesViewController.h"

@interface PhotoPagesViewController ()

@end

@implementation PhotoPagesViewController

@synthesize scrollView, pageControl, pageIndicatorLabel;
@synthesize category;
@synthesize photosArray;
@synthesize numItemsLoaded, fetchingPhotos;
@synthesize currentPage;
@synthesize photojournalWebAPIForPhotosRettrieving;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(id)initWithCategoryID:(NSInteger)categoryID forPage:(NSInteger)_currentPage {
    self = [super init];
    if(self){
        // Custom initialization
        category = categoryID;
        
        currentPage = _currentPage;
        
        self.photosArray = [NSMutableArray array];
        numItemsLoaded = 0;
        fetchingPhotos = YES;
        pageControlBeingUsed = NO;
        
        photojournalWebAPIForPhotosRettrieving = [[PhotojournalWebAPI alloc] init];
        photojournalWebAPIForPhotosRettrieving.delegate = self;
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self fillPages];
    [self gotoPage:currentPage];
}

#pragma mark -
#pragma mark ---------- IBACTION METHODS ----------

-(IBAction)backButtonClicked:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)previousPageButtonClicked:(UIButton *)button {
    if (currentPage == 0 ) return;
    currentPage -= 1;
    [self gotoPage:currentPage];
}

-(IBAction)nextPageButtonClicked:(UIButton *)button {
    if (currentPage == photosArray.count - 1 ) return;
    currentPage += 1;
    [self gotoPage:currentPage];
    
}

- (IBAction)changePage {
    // update the scroll view to the appropriate page
    CGRect frame;
    frame.origin.x = self.scrollView.frame.size.width * self.pageControl.currentPage;
    frame.origin.y = 0;
    frame.size = self.scrollView.frame.size;
    [self.scrollView scrollRectToVisible:frame animated:YES];
    
    pageControlBeingUsed = YES;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    pageControlBeingUsed = NO;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    pageControlBeingUsed = NO;
}


#pragma mark -
#pragma mark ---------- UIScrollViewDelegate METHODS ----------

-(void)scrollViewDidScroll:(UIScrollView *)_scrollView {
    // Update the page when more than 50% of the previous/next page is visible
    CGFloat pageWidth = self.scrollView.frame.size.width;
    NSLog(@"pageWidth ==> %f", pageWidth);
    int page = floor((self.scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.pageControl.currentPage = page;
    currentPage = page;
    [self loadImageForPage:currentPage];
}


#pragma mark -
#pragma mark ---------- URLCONNECTION METHODS ----------
-(void)getPhotosFromServer {
    //    if (![SharedStore store].hostActive) {
    //        NSLog(@"DONT getPhotosFromServer");
    //        fetchingPhotos = NO;
    //        [self.photoListTableView reloadData];
    //        return;
    //    }
    
    NSLog(@"getPhotosFromServer");
    [photojournalWebAPIForPhotosRettrieving getPhotoListForID:category WhenOffset:numItemsLoaded inNumber:20];
}

#pragma mark -
#pragma mark ---------- ClutterlyWebAPIDelegate DELEGATE METHODS ----------

-(void)photosRetreivingFailedWithError:(NSError *)error {
    NSLog(@"photosRetreivingFailedWithError");
    fetchingPhotos = NO;
//    [self.photoListTableView reloadData];    
}

-(void)photosRetreivingCompletedWithResponse:(NSData *)responseData {
    NSString *responseString = [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease];
    NSDictionary *responseDictionary = [[[NSDictionary alloc] initWithDictionary:[responseString JSONValue]] autorelease];
    
    NSLog(@"responseDictionary ===> %@", responseDictionary);
    
    if ([[responseDictionary valueForKey:ParamsKey_photos] isKindOfClass:[NSArray class]]) {
        [[SharedStore store].DBManager parseServerResponseItemsListDictionary:responseString];
    }
    else {
    }
}


#pragma mark -
#pragma mark ---------- CUSTOM METHODS ----------
-(void)customizeView {
}

-(void)fillPages {
    
//    [photosArray addObjectsFromArray:[[SharedStore store].DBManager getAllPhotos]];
    [photosArray addObjectsFromArray:[[SharedStore store].DBManager getAllPhotosForCategoryID:category]];
    pageControl.numberOfPages = photosArray.count;
    
    for (int i = 0; i < photosArray.count; i++) {
        CGRect frame;
        frame.origin.x = self.scrollView.frame.size.width * i;
        frame.origin.y = 0;
        frame.size = self.scrollView.frame.size;
                
        PhotoPageVIew *photoPageView = [[[PhotoPageVIew alloc] initWithFrame:frame] autorelease];
        photoPageView.tag = i;
        [photoPageView customizeViewForPhoto:(Photo*)[photosArray objectAtIndex:i]];
        [self.scrollView addSubview:photoPageView];
    }
    
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * photosArray.count, self.scrollView.frame.size.height);
}

-(void)gotoPage:(NSInteger)pageNo {
    // update the scroll view to the appropriate page
    CGRect frame;
    frame.origin.x = self.scrollView.frame.size.width * currentPage;
    frame.origin.y = 0;
    frame.size = self.scrollView.frame.size;
    [self.scrollView scrollRectToVisible:frame animated:YES];
    
    
    [self loadImageForPage:pageNo];
}

-(void)loadImageForPage:(NSInteger)pageNo {
    pageIndicatorLabel.text = [NSString stringWithFormat:@"%d / %d", pageNo + 1, photosArray.count];

    for(UIView *subview in self.scrollView.subviews)
    {
        if ([subview isKindOfClass:[PhotoPageVIew class]]) {
            if (((PhotoPageVIew*)subview).tag == pageNo) {
                PhotoPageVIew *photoPageVIew = (PhotoPageVIew*)subview;
                [photoPageVIew getImageFromServer];
            }
        }
    }    
}

#pragma mark -
#pragma mark ---------- MEMORY MANAGEMENT ----------

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [scrollView release];
    [pageControl release];
    [pageIndicatorLabel release];
    
    if (photojournalWebAPIForPhotosRettrieving) {
        [photojournalWebAPIForPhotosRettrieving cancelAllConnections];
    }
    photojournalWebAPIForPhotosRettrieving.delegate = nil;
    [photojournalWebAPIForPhotosRettrieving release];
    
    
    [super dealloc];
}

@end
