//
//  CategoryListViewController.m
//  Photojournal
//
//  Created by samesh on 20/4/13.
//  Copyright (c) 2013 bajratechnologies. All rights reserved.
//

#import "CategoryListViewController.h"
#import "SharedStore.h"

@interface CategoryListViewController ()

@end

@implementation CategoryListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[self navigationController] setNavigationBarHidden:YES animated:NO];
}

#pragma mark -
#pragma mark ---------- IBACTION METHODS ----------

-(IBAction)menuButtonClicked:(UIButton *)button {
    PhotosViewController *photosViewController = [[[PhotosViewController alloc] initWithCategoryID:button.tag] autorelease];
    [self.navigationController pushViewController:photosViewController animated:YES];
}


#pragma mark -
#pragma mark ---------- CUSTOM METHODS ----------
-(void)customizeView {
}


#pragma mark -
#pragma mark ---------- MEMORY MANAGEMENT ----------

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}

- (void)dealloc {
    [super dealloc];
}


@end
